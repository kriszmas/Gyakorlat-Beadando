package com.example.securityrole;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecurityRoleApplication {

    public static void main(String[] args) {
        SpringApplication.run(SecurityRoleApplication.class, args);
    }

}
